            function makeThisBreak() {
                alert('Welcome to JavaScript Hell!');
            }